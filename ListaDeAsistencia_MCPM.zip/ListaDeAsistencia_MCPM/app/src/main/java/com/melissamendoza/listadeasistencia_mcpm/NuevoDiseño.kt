package com.melissamendoza.listadeasistencia_mcpm

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class NuevoDiseño : BottomSheetDialogFragment() {

    interface OnItemAddedListener {
        fun onItemAddedListener(newItem: Alumnos)
    }

    private var itemAddedListener: OnItemAddedListener? = null

    fun setOnItemAddedListener(listener: Alumnos) {
        itemAddedListener
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.bsd_new_country, container, false)

        val button = view.findViewById<Button>(R.id.bsd_submit)

        button.setOnClickListener {
            val alumnos = Alumnos(
                9,
                "China",
                "Pekin",
                "Asia",
                "https://cdn.britannica.com/90/7490-004-BAD4AA72/Flag-China.jpg"
               )
            itemAddedListener?.onItemAddedListener(alumnos)
            dismiss()
        }

        return view
    }
}