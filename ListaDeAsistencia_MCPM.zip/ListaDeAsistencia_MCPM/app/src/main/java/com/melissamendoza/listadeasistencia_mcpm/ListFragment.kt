package com.melissamendoza.listadeasistencia_mcpm

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ListFragment : Fragment() {

    private var countries : MutableList<Alumnos> = mutableListOf()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        initData()
        val view = inflater.inflate(R.layout.fragment_list, container, false)

        val fab = view.findViewById<FloatingActionButton>(R.id.fab_new)

        val adapter = DiseñoDeCartas(countries)

        val recyclerView =
            view.findViewById<RecyclerView>(
                R.id.countriesRecycler
            )



        //Variables para el elemento nuevo
        var _id : Int = 0
        var _name : String
        var _capital : String
        var _continent : String
        var _image : String

        fab.setOnClickListener {


            // Show Bottom Sheet Dialog and add a new item
            val bottomSheetFragment = BottomSheetDialog(view.context)
            val parentView : View = layoutInflater.inflate(R.layout.bsd_new_country, null)
            bottomSheetFragment.setContentView(parentView)
            bottomSheetFragment.show()

            //elementos del formulario bsd
            val newId = parentView.findViewById<EditText>(R.id.bsd_country_id)
            val newName = parentView.findViewById<EditText>(R.id.bsd_country_name)
            val newCapital = parentView.findViewById<EditText>(R.id.bsd_country_capital)
            val newContinent = parentView.findViewById<EditText>(R.id.bsd_country_continent)
            val newImage = parentView.findViewById<EditText>(R.id.bsd_country_image)


            val button = parentView.findViewById<Button>(R.id.bsd_submit)

            //boton guardar del bsd, asignación de valores y creación del nuevo elemento
            button.setOnClickListener{
                _id = newId.text.toString().toInt()
                _name = newName.text.toString()
                _capital = newCapital.text.toString()
                _continent = newContinent.text.toString()
                _image = newImage.text.toString()



                val newProductAdd = Alumnos(
                    _id,
                    _name,
                    _capital,
                    _continent,
                    _image,

                )

                countries.add(newProductAdd)

                recyclerView.adapter?.notifyDataSetChanged()

                bottomSheetFragment.dismiss()
            }
        }

        //Lista anchura completa
        val layoutManager = LinearLayoutManager(container?.context)
        //Cuadricula 2X2
        //val gridLayoutManager = GridLayoutManager(container?.context, 2)

        recyclerView?.layoutManager = layoutManager
        recyclerView?.adapter = adapter

        return view
    }

    private fun initData() {

        countries = mutableListOf(
            Alumnos(1, "melissa", "mendoza", "primera ", "https://cdn.wanderer.moe/genshin-impact/character-icons/ui-avataricon-tartaglia.png"),
            Alumnos(2, "paulina", "cordova", "segunda", "https://cdn.wanderer.moe/genshin-impact/character-icons/ui-avataricon-zhongli.png"),
            Alumnos(4, "jose", "gonzales", "primero", "https://cdn.wanderer.moe/genshin-impact/character-icons/ui-avataricon-wriothesley.png"),
            Alumnos(5, "alejando", "ruiz", "segundo", "https://cdn.wanderer.moe/genshin-impact/character-icons/ui-avataricon-wanderer.png"),
            Alumnos(6, "manuel", "miranda", "tercero", "https://cdn.wanderer.moe/genshin-impact/character-icons/ui-avataricon-yaoyao.png"),
            Alumnos(7,"felix", "kim", "segundo", "https://cdn.wanderer.moe/genshin-impact/character-icons/ui-avataricon-yelan.png"),
            Alumnos(8, "jungkook", "jeon", "primero", "https://cdn.wanderer.moe/genshin-impact/character-icons/ui-avataricon-xiao.png")
        )
    }
}