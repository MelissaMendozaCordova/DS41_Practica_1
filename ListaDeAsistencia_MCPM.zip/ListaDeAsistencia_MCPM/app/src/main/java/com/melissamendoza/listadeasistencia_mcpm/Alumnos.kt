package com.melissamendoza.listadeasistencia_mcpm

data class Alumnos(
    val id: Int,
    val nombre: String,
    val apellido: String,
    val grupo: String,
    val imagen: String
)
