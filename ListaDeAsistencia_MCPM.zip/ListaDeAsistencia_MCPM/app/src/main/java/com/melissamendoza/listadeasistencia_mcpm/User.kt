package com.melissamendoza.listadeasistencia_mcpm

data class User(
    val id: Int,
    val email: String,
    val password: String

)
